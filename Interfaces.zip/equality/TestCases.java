import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalTime;

import org.junit.Test;

public class TestCases
{
   @Test
   public void testExercise1()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));

      assertTrue(one.equals(two));
      assertTrue(two.equals(one));
   }

   @Test
   public void testExercise2()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 10), LocalTime.of(10, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(1, 10), LocalTime.of(2, 0));

      assertFalse(one.equals(two));
      assertFalse(two.equals(one));
   }

   @Test
   public void testExercise3()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));

      assertEquals(one.hashCode(), two.hashCode());
   }

   @Test
   public void testExercise4()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 10), LocalTime.of(10, 0));
      final CourseSection two = new CourseSection("CSC", "203", 34,
         LocalTime.of(9, 10), LocalTime.of(10, 0));

      assertNotEquals(one.hashCode(), two.hashCode());
   }
   @Test
   public void testExercise5() {
      final CourseSection one = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));
      final CourseSection two = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));

      assertEquals(one.hashCode(), two.hashCode());
   }

   @Test

   public void testStudent() {
      ArrayList<CourseSection> s = new ArrayList<>();
      final CourseSection one = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));

      s.add(one);

      final Student st = new Student("Pasala", "Dakshesh", 18, s);

      ArrayList<CourseSection> s1 = new ArrayList<>();
      final CourseSection three = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));


      s1.add(three);

      final Student st1 = new Student("Pasala", "Dakshesh", 18, s);


      assertTrue(st.equals(st1));

   }
   @Test
   public void testStudent2() {
      ArrayList<CourseSection> s = new ArrayList<>();
      final CourseSection one = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));

      s.add(one);

      final Student st = new Student("Pasal", "Dakshesh", 18, s);

      ArrayList<CourseSection> s1 = new ArrayList<>();
      final CourseSection three = new CourseSection("CSC", "202", 39,
              LocalTime.of(5, 10), LocalTime.of(11, 0));


      s1.add(three);

      final Student st1 = new Student("Pasala", "Dakshesh", 18, s1);

      assertFalse(st.equals(st1));

   }
   @Test
   public void testExercise6() {
      final CourseSection one = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));
      final CourseSection three = new CourseSection("CSC", "202", 39,
              LocalTime.of(1, 10), LocalTime.of(2, 0));

      assertFalse(one.equals(three));
   }

   @Test

   public void testStudent3() {
      ArrayList<CourseSection> s = new ArrayList<>();
      final CourseSection one = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));

      s.add(one);

      final Student st = new Student("Pasala", "Dakshesh", 18, s);

      ArrayList<CourseSection> s1 = new ArrayList<>();
      final CourseSection three = new CourseSection("CSC", "202", 39,
              LocalTime.of(6, 40), LocalTime.of(12, 0));


      s1.add(three);

      final Student st1 = new Student("Pasala", "Dakshesh", 18, s);


      assertEquals(st.hashCode(), st1.hashCode());

   }

}
