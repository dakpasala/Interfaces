import java.time.LocalTime;
import java.util.*;

class CourseSection
{
   private final String prefix;
   private final String number;
   private final int enrollment;
   private final LocalTime startTime;
   private final LocalTime endTime;

   public CourseSection(final String prefix, final String number,
      final int enrollment, final LocalTime startTime, final LocalTime endTime)
   {
      this.prefix = prefix;
      this.number = number;
      this.enrollment = enrollment;
      this.startTime = startTime;
      this.endTime = endTime;
   }
   public String getPrefix() {
      return this.prefix;
   }
   public String getNumber() {
      return this.number;
   }

   public int getEnrollment() {
      return enrollment;
   }

   public LocalTime getStartTime() {
      return startTime;
   }

   public LocalTime getEndTime() {
      return endTime;
   }

   public boolean equals(Object c) {
      if (c == null) {
         return false;
      }
      if (this.getClass() != c.getClass()) {
         return false;
      }
      if (Objects.equals(this.prefix, ((CourseSection) c).getPrefix()) && Objects.equals(this.number, ((CourseSection) c).getNumber()) &&
      Objects.equals(this.enrollment, ((CourseSection) c).getEnrollment()) && Objects.equals(this.startTime, ((CourseSection) c).getStartTime())
      && Objects.equals(this.endTime, ((CourseSection) c).getEndTime())) {
         return true;
      }
      return false;

   }
   @Override
   public int hashCode() {
      int result = 29;
      result += result * 10 + (this.prefix != null ? this.prefix.hashCode(): 0);
      result += result * 10 + (this.prefix != null ? this.number.hashCode(): 0);
      result += result * 10 + this.enrollment * 29;
      result += result * 10 + (this.prefix != null ? this.startTime.hashCode(): 0);
      result += result * 10 + (this.prefix != null ? this.endTime.hashCode(): 0);
      return result;
   }



   // additional likely methods not defined since they are not needed for testing
}
