interface Operation
{
   double evaluate(Bindings bindings);
}
