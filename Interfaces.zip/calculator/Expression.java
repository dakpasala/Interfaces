public interface Expression
   extends Operation
{
}
